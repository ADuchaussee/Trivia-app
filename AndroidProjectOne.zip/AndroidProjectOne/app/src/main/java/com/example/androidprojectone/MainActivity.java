package com.example.androidprojectone;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.Set;

public class MainActivity extends AppCompatActivity {
    private TextView mQuestionTV;
    private TextView mAnswerTV;
    private int mCurrentIndex = 0;
    private int [] mQuestionBank = new int[]
            {R.string.question_text1,R.string.question_text2,R.string.question_text3};
    private boolean [] mAnswerBank = new boolean[]{true, false, true};
    private Button mTrueButton;
    private Button mFalseButton;
    private Button mNextButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mQuestionTV=(TextView)findViewById(R.id.question_textview);
        mQuestionTV.setText(mQuestionBank[mCurrentIndex]);
        mAnswerTV=(TextView)findViewById(R.id.answer_button);
        mTrueButton = (Button) findViewById(R.id.true_button);
        mTrueButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mAnswerBank[mCurrentIndex] == false)
                    mAnswerTV.setText(R.string.incorrect_text);

                else if (mAnswerBank[mCurrentIndex] == true)
                    mAnswerTV.setText(R.string.correct_text);
            }//onClick ends

        });//setListen ends
        mFalseButton = (Button)  findViewById(R.id.false_button);
        mFalseButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mAnswerBank[mCurrentIndex] == true)
                    mAnswerTV.setText(R.string.incorrect_text);

                else if (mAnswerBank[mCurrentIndex] == false)
                    mAnswerTV.setText(R.string.correct_text);

            }//onClick ends

        });//setListen ends

        mNextButton = (Button) findViewById(R.id.next_button);
        mNextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               // if (mCurrentIndex2) {
                   // mCurrentIndex = 0;
               //
                if (mCurrentIndex == 2) {
                    mCurrentIndex = 0;
                    mQuestionTV.setText(mQuestionBank[mCurrentIndex]);
                }
                else{
                    mCurrentIndex++;
                }
                mQuestionTV.setText(mQuestionBank[mCurrentIndex]);

            }//onClick ends
        });//setListen ends
    }//onCreate ends
}//Class ends